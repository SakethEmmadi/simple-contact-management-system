const form = document.getElementById('grnCreateForm');
const tableBody = document.getElementById('grnTable').querySelector('tbody');

// Load GRN records on page load
document.addEventListener('DOMContentLoaded', loadRecords);


form.addEventListener('submit', (e) => {
  e.preventDefault();
  const grn = getFormData();
  if (!validateForm(grn)) return alert('Please fill out all fields correctly.');

  const records = getGRNRecords();
  const existingIndex = records.findIndex(record => record.grnNumber === grn.grnNumber);

  if (existingIndex !== -1) {
    records[existingIndex] = grn; 
    alert('Record updated successfully!');
  } else {
    records.push(grn); 
    alert('Record added successfully!');
  }

  saveGRNRecords(records);
  resetForm();
  renderTable(records);
});

// Load GRN records from localStorage
function getGRNRecords() {
  return JSON.parse(localStorage.getItem('grnRecords')) || [];
}

// Save GRN records to localStorage
function saveGRNRecords(records) {
  localStorage.setItem('grnRecords', JSON.stringify(records));
}


function getFormData() {
  return {
    grnNumber: document.getElementById('grnNumber').value,
    poNumber: document.getElementById('poNumber').value,
    itemName: document.getElementById('itemName').value,
    receivedQuantity: parseInt(document.getElementById('receivedQuantity').value, 10),
    receivedDate: document.getElementById('receivedDate').value,
    supplierName: document.getElementById('supplierName').value,
    status: document.getElementById('status').value,
  };
}


function resetForm() {
  form.reset();
}

function validateForm(grn) {
  return grn.grnNumber && grn.poNumber && grn.itemName && grn.receivedQuantity > 0 && grn.receivedDate && grn.supplierName && grn.status;
}


function renderTable(records) {
  tableBody.innerHTML = '';
  records.forEach((record, index) => {
    const row = document.createElement('tr');
    row.setAttribute("class","row")
    row.innerHTML = `
      <td>${record.grnNumber}</td>
      <td>${record.poNumber}</td>
      <td>${record.itemName}</td>
      <td>${record.receivedQuantity}</td>
      <td>${record.receivedDate}</td>
      <td>${record.supplierName}</td>
      <td>${record.status}</td>
      <td>
        <button class="edit" onclick="editRecord(${index})">Edit</button>
        <button class="delete" onclick="deleteRecord(${index})">Delete</button>
      </td>
    `;
    tableBody.appendChild(row);
  });
}


function editRecord(index) {
  const records = getGRNRecords();
  const record = records[index];
  for (const key in record) {
    if (document.getElementById(key)) {
      document.getElementById(key).value = record[key];
    }
  }
}


function deleteRecord(index) {
  const records = getGRNRecords();
  records.splice(index, 1);
  saveGRNRecords(records);
  renderTable(records);
}

// Load and render records
function loadRecords() {
  renderTable(getGRNRecords());
}


